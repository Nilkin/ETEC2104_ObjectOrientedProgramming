#include "Node.h"

Node::Node()
{
    //ctor
}

Node::~Node()
{
    //dtor
}
