//
//  ___FILENAME___
//  Tonic
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//

#include "___FILEBASENAME___.h"

namespace Tonic { namespace Tonic_{
  
  ___FILEBASENAME____::___FILEBASENAME____(){
    
  }
  
  ___FILEBASENAME____::~___FILEBASENAME____(){
    
  }
  
  void ___FILEBASENAME____::computeOutput(const SynthesisContext_ & context){
  
  }
  
  
  
} // Namespace Tonic_
  
  
  
} // Namespace Tonic
