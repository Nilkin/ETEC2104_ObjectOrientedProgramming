//
//  SynthDemoDef.m
//  TonicDemo
//
//  Created by Morgan Packard on 3/28/13.
//  Copyright (c) 2013 Morgan Packard. All rights reserved.
//

#import "SynthDemoDef.h"

@implementation SynthDemoDef

// nil initial values are fine

@end
