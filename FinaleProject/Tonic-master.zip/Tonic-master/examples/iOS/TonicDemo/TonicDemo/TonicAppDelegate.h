//
//  TonicAppDelegate.h
//  TonicDemo
//
//  Created by Morgan Packard on 1/25/13.

//

#import <UIKit/UIKit.h>

@interface TonicAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) UINavigationController *rootNavController;

@end
