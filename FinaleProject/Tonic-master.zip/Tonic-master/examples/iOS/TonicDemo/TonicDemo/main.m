//
//  main.m
//  TonicDemo
//
//  Created by Morgan Packard on 1/25/13.

//

#import <UIKit/UIKit.h>

#import "TonicAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([TonicAppDelegate class]));
  }
}
