//
//  StereoFixedTestGen.cpp
//  Tonic
//
//  Created by Nick Donaldson on 3/9/13.

//

#include "StereoFixedTestGen.h"

namespace Tonic { namespace Tonic_{
  
  StereoFixedTestGen_::StereoFixedTestGen_(){
    
  }
  
  StereoFixedTestGen_::~StereoFixedTestGen_(){
    
  }
  
} // Namespace Tonic_
  
  
  
} // Namespace Tonic
