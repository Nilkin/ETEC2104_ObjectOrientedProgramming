//
//  TonicLoggingTests.h
//  TonicDemo
//
//  Created by Nick D on 4/21/13.
//  Copyright (c) 2013 Morgan Packard. All rights reserved.
//

// These tests produce an output in the console and are intended for visual verification of algorithms

#import <XCTest/XCTest.h>

@interface TonicLoggingTests : XCTestCase

@end
