//
//  TonicTests.h
//  TonicTests
//
//  Created by Nick D on 4/19/13.
//  Copyright (c) 2013 Morgan Packard. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface TonicTests : XCTestCase

@end
