//
//  ControlCounter.cpp
//  Tonic
//
//  Created by Morgan Packard on 4/15/13.
//
//
// See LICENSE.txt for license and usage information.
//

#include "ControlCounter.h"

namespace Tonic { namespace Tonic_{
  
  ControlCounter_::ControlCounter_(){
    end = ControlValue(std::numeric_limits<float>::infinity());
  }
  
} // Namespace Tonic_
  
  
  
} // Namespace Tonic
