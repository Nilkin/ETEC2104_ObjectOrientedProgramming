//
//  ControlPulse.cpp
//  Tonic
//
//  Created by Nick Donaldson on 3/10/13.

//

#include "ControlPulse.h"

namespace Tonic { namespace Tonic_{
  
  ControlPulse_::ControlPulse_() : lastOnTime_(0)
  {}
  
} // Namespace Tonic_
  
} // Namespace Tonic
