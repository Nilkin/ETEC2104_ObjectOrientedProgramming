//
//  ControlConditioner.cpp
//  TonicDemo
//
//  Created by Morgan Packard on 3/4/13.

//

#include "ControlConditioner.h"

namespace Tonic{

namespace Tonic_{

  void ControlConditioner_::input(ControlGenerator input){
    input_ = input;
  }

}

}