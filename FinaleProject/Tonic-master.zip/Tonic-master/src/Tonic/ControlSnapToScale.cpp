//
//  ControlSnapToScale.cpp
//  Tonic
//
//  Created by Morgan Packard on 3/24/13.

//

#include "ControlSnapToScale.h"

namespace Tonic { namespace Tonic_{
  
} // Namespace Tonic_
  
  
  
} // Namespace Tonic
