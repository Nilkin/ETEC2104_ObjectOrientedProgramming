//
//  ControlMetro.cpp
//  Tonic
//
//  Created by Nick Donaldson on 3/10/13.

//

#include "ControlMetro.h"

namespace Tonic { namespace Tonic_{
  
  ControlMetro_::ControlMetro_() : lastClickTime_(0) {}
  
} // Namespace Tonic_
  
} // Namespace Tonic
