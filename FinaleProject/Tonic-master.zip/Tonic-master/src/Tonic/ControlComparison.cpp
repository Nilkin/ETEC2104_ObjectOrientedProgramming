//
//  ControlComparison.cpp
//  Tonic
//
//  Created by Nick Donaldson on 5/31/13.
//

#include "ControlComparison.h"

namespace Tonic { namespace Tonic_{
  
  ControlComparisonOperator_::ControlComparisonOperator_() :
    lhsGen_(ControlValue(0)),
    rhsGen_(ControlValue(0))
  {};
  
} // Namespace Tonic_
  
  
  
} // Namespace Tonic
