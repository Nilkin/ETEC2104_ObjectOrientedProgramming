//
//  ControlMidiToFreq.cpp
//  TonicDemo
//
//  Created by Morgan Packard on 3/5/13.

//

#include "ControlMidiToFreq.h"


namespace Tonic{

  namespace Tonic_{
  
  }
}
